import UIKit
import SceneKit

public class InstrumentSceneView: SCNView {
    
    let instrument: Piano!
    let slowMotionEnabled: Bool!
    
    // the init() of the super class was augmented with two new arguments: the instrument and a slo-mo flag
    public init(with instrument: Piano, slowMotionEnabled: Bool, frame: CGRect = Constants.defaultFrame,
                         options: [String : Any]? = nil) {
        self.instrument = instrument
        self.slowMotionEnabled = slowMotionEnabled
        super.init(frame: frame, options: options)
        setupScene()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        self.instrument = Piano(playing: Note.c)
        self.slowMotionEnabled = false
        super.init(coder: aDecoder)
    }
    
    // called when the view is initialized
    func setupScene() {
        let pianoScene = SCNScene(named: "Scenes/cs60_30.scn")!
        let pianoSceneSloMo = SCNScene(named: "Scenes/cs60.scn")!
        
        // depending on the slo-mo setting, the respective scene is chosen
        if slowMotionEnabled {
            scene = pianoSceneSloMo
        } else {
            scene = pianoScene
        }
        
        // setup for the camera
        allowsCameraControl = true
        defaultCameraController.interactionMode = .orbitTurntable
        defaultCameraController.inertiaEnabled = true
        defaultCameraController.inertiaFriction = 0.5
        
        autoenablesDefaultLighting = true
        antialiasingMode = .multisampling4X
        showsStatistics = false
        isPlaying = false
        loops = false
    }
    
    var firstTouchedNode: SCNNode!
    var lastTouchedNode: SCNNode!
    
    // the following three functions are used to determine whether a part of the key was touched
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let firstTouch = touches.first!
        if let hit = self.hitTest(firstTouch.location(in: self), options: nil).first {
            firstTouchedNode = hit.node
        }
    }
    
    override public func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        let lastTouch = touches.first!
        if let hit = self.hitTest(lastTouch.location(in: self), options: nil).first {
            lastTouchedNode = hit.node
            decideIfKeyWasPressed()
            firstTouchedNode = nil
            lastTouchedNode = nil
        }
    }
    
    func decideIfKeyWasPressed() {
        // if a part of the key was touched, a sound is played
        if (firstTouchedNode == lastTouchedNode) {
            self.stop(nil)
            self.play(nil)
            
            firstTouchedNode.runAction(getAction(fromKey: instrument.currentNote.rawValue))
        }
    }
    
    // serves the right SCNAction depending on which note was chosen by the user and whether slo-mo was activated or deactivated
    func getAction(fromKey key: String) -> SCNAction {
        var fileName: String
        
        if slowMotionEnabled {
            fileName = "Notes/\(key)Slo.mp3"
        } else {
            fileName = "Notes/\(key).mp3"
        }
        
        let source = SCNAudioSource(fileNamed: fileName)
        return SCNAction.playAudio(source!, waitForCompletion: false)
    }
}

public struct Constants {
    public static let defaultFrame = CGRect(x: 0.0, y: 0.0, width: 500.0, height: 600.0)
}
