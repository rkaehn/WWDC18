import Foundation

public class Piano {
    
    public let currentNote: Note!
    
    public init(playing note: Note) {
        currentNote = note
    }
    
}
