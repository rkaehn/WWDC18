import Foundation

public enum Note: String {
    case c = "c"
    case d = "d"
    case e = "e"
    case f = "f"
    case g = "g"
    case a = "a"
    case h = "h"
}
