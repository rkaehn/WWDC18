//#-hidden-code
import PlaygroundSupport
//#-end-hidden-code
/*:
 # THE GRAND PIANO
 ---
 Have you ever wondered how the sound of a traditional grand piano is actually created behind the keys?
 This playground will teach you all about that.\
 Start by exploring the scene!
 
* Note:
    * drag with one finger to rotate around the model
    * use two fingers to zoom in and out of the scene
    * tap the key to play a note
 
 \
 You can also change the note that the key is playing by choosing a different one in the following statement:
 */
let piano = Piano(playing: Note.c)
/*:
 To really help you get a better look at the inner workings, try enabling the slow-motion camera.
 */
PlaygroundPage.current.liveView = InstrumentSceneView(with: piano, slowMotionEnabled: false)
